package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Binding;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Club;
import model.ClubDAOException;
import model.Member;

public class SignUpController implements Initializable {


    @FXML
    private TextField creditCardField;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField nickNameField;


    @FXML
    private TextField phoneNumberField;
    
    private Club club;
    @FXML
    private Label taken;
    @FXML
    private ImageView myImageView;
    @FXML
    private Label pass;
    
    private Member m;
    
    @FXML
    private Button submit;
    
    @FXML
    private PasswordField password;
    
    private BooleanProperty validNickname;
    private BooleanProperty validname;
    private BooleanProperty validPassword;
  
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            club= Club.getInstance();
        } catch (ClubDAOException ex) {
            Logger.getLogger(SignUpController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SignUpController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        validNickname = new SimpleBooleanProperty(Boolean.FALSE);
        validname = new SimpleBooleanProperty(Boolean.FALSE);
        validPassword = new SimpleBooleanProperty(Boolean.FALSE);
        
        
        
        BooleanBinding validFields = Bindings.and(validNickname, validPassword).and(validname);
        //submit.disableProperty().bind(Bindings.not(validFields));
        
    }
    
    
@FXML
void SubmitButton(ActionEvent event) throws IOException, ClubDAOException {
   String name = firstNameField.getText();
    String surname = lastNameField.getText();
    String telephone = phoneNumberField.getText();
    String nickname = nickNameField.getText();
    String password1 = password.getText();
    String creditCard = creditCardField.getText();
    int svc = 0; // Replace with the appropriate value for svc
    Image image = null; // Replace with the image for the member, if available

    try {
        club.registerMember(name, surname, telephone, nickname, password1, creditCard, svc, image);
        System.out.println(club.getMembers());

        Stage stage = (Stage) submit.getScene().getWindow();
        stage.close();

        // Show confirmation dialog
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Registration Successful");
        alert.setHeaderText(null);
        alert.setContentText("Member registered successfully!");

        alert.showAndWait();

        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/views/HomeScreen.fxml"));
        primaryStage.setTitle("Home Screen");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    } catch (ClubDAOException e) {
        if (e.getMessage().contains("UNIQUE constraint failed: member.nickName")) {
            // Handle the constraint violation (duplicate nickname) appropriately
            taken.setText("Nickname already taken"); // Display an error message to the user
        } else {
            // Handle other ClubDAOException cases
            System.out.println("Error: Failed to register member");
            e.printStackTrace();
        }
    } catch (IOException e) {
        // Handle the IOException
        System.out.println("Error: Failed to load HomeScreen.fxml");
        e.printStackTrace();
    }

}
}