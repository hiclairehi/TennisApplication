package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Binding;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Club;
import model.ClubDAOException;
import model.Member;

public class SignUpController implements Initializable {


    @FXML
    private TextField creditCardField;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField nickNameField;


    @FXML
    private TextField phoneNumberField;
    
    private Club club;
    @FXML
    private Label taken;
    @FXML
    private ImageView myImageView;
    @FXML
    private Label pass;
    
    private Member m;
    
    @FXML
    private Button submit;
    
    @FXML
    private PasswordField password;
    
    private BooleanProperty validNickname;
    private BooleanProperty validPassword;
    private BooleanProperty validData;
    @FXML
    private TextField svc;
    
    private Image image;
  
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            club= Club.getInstance();
        } catch (ClubDAOException ex) {
            Logger.getLogger(SignUpController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SignUpController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        validNickname= new SimpleBooleanProperty(Boolean.FALSE);
        validPassword = new SimpleBooleanProperty(Boolean.FALSE);
        validData = new SimpleBooleanProperty(Boolean.FALSE);
        
        BooleanBinding validFields =Bindings.and(validNickname, validPassword).and(validData);
        submit.disableProperty().bind(Bindings.not(validFields));
       
        nickNameField.focusedProperty().addListener((observable,oldValue, newValue)->{
            if(!newValue){
                checkNickname();
            }
        });
        
        password.focusedProperty().addListener((observable, oldValue, newValue)->{
            if(!newValue){ checkPassword();}
        });
        
        firstNameField.focusedProperty().addListener((observable,ooldValue,newValue)->{
            if(!newValue){ 
                checkData();
            }
        });
        
        lastNameField.focusedProperty().addListener((observable,oldValue, newValue)->{
            if(!newValue){
                checkData();
            }
        });
        
        
    }
    
    
    @FXML
    void SubmitButton(ActionEvent event) throws IOException, ClubDAOException  {
        String svs=svc.textProperty().getValueSafe();
        int s=0;
        if(!svs.isEmpty()){  s = Integer.parseInt(svc.getText());}
        
m=club.registerMember(firstNameField.getText(), lastNameField.getText(), phoneNumberField.getText(), nickNameField.getText(), password.getText(), creditCardField.getText(), s, image);
       
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Sign up confirmation");
        alert.setHeaderText("Your sign up was successful");
        alert.setContentText("Login to continue");
       
        Optional<ButtonType> result = alert.showAndWait();
        
        if(result.isPresent() && result.get() ==ButtonType.OK){
            
            FXMLLoader loader  = new FXMLLoader(getClass().getResource("/views/LoginFXML.fxml"));
            Parent root = loader.load();
            
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            
            stage.setTitle("GreenBall");
            stage.setScene(new Scene(root));
            stage.show();
            Stage stge = (Stage) submit.getScene().getWindow();
            stge.close();
            
            
            
                   
        }
        
    }
    

     public void checkNickname(){
        if(club.existsLogin(nickNameField.textProperty().getValueSafe()) || nickNameField.textProperty().getValueSafe().contains(" ")){
                    taken.setText("Invalid nickname, try again.");
                    taken.setVisible(true);
                    validNickname.setValue(Boolean.FALSE);
                    nickNameField.requestFocus();
                    
        }else{
            validNickname.setValue(Boolean.TRUE);
            taken.setVisible(false);
        }
    
    }
     
     public void checkData(){
        if(!firstNameField.textProperty().getValueSafe().isEmpty() && !lastNameField.textProperty().getValueSafe().isEmpty()){
            validData.setValue(Boolean.TRUE);
        }else{ 
            validData.setValue(Boolean.FALSE);
        
        }
    }
     
     public void checkPassword(){
        if(password.textProperty().getValueSafe().length()<6){
            validPassword.setValue(Boolean.FALSE);
            pass.setVisible(true);
            pass.setText("Password must be at least 6 characters.");
            password.requestFocus();
        }else{
            validPassword.setValue(Boolean.TRUE);
            pass.setVisible(false);
        }
    }
     
     

    @FXML
    private void addPicture(MouseEvent event) throws FileNotFoundException {
        
        FileChooser imageChooser = new FileChooser();
        imageChooser.setTitle("Choose a profile picture");
        imageChooser.getExtensionFilters().add(new ExtensionFilter("Images","*.png","*.jpg"));
        File selectedImage = imageChooser.showOpenDialog(((Node) event.getSource()).getScene().getWindow());
        if(selectedImage != null){
            String url =selectedImage.getAbsolutePath();
            image = new Image(new FileInputStream(url));
            myImageView.imageProperty().set(image);
        }
        
    }
}

