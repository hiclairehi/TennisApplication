/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author aless
 */
public class HomeScreenController implements Initializable {

    @FXML
    private Button LogInButton;
    @FXML
    private Button SignUpButton;
    @FXML
    private Label homeLabel;
    @FXML
    private Button BookTennisCourt;
    @FXML
    private Button myReservationButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void login(ActionEvent event) throws IOException {
        Stage stage = (Stage) LogInButton.getScene().getWindow();
        stage.close();
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/views/LoginFXML.fxml"));
        primaryStage.setTitle("Home Menu");
        primaryStage.setScene(new Scene(root));  
        primaryStage.show();
    }

    @FXML
    private void signUp(ActionEvent event) throws IOException {
        Stage stage = (Stage) SignUpButton.getScene().getWindow();
        stage.close();
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/views/SignUpFXML.fxml"));
        primaryStage.setTitle("Home Menu");
        primaryStage.setScene(new Scene(root));  
        primaryStage.show();
    }

    @FXML
    private void BookTennisCourtAction(ActionEvent event) throws IOException {
        Stage stage = (Stage) BookTennisCourt.getScene().getWindow();
        stage.close();
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/views/ReserveCourt_V3.fxml"));
        primaryStage.setTitle("Home Menu");
        primaryStage.setScene(new Scene(root));  
        primaryStage.show();
    }

    @FXML
    private void ReservationAction(ActionEvent event) throws IOException {
        Stage stage = (Stage) myReservationButton.getScene().getWindow();
        stage.close();
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/views/MyReservations.fxml"));
        primaryStage.setTitle("Home Menu");
        primaryStage.setScene(new Scene(root));  
        primaryStage.show();
    }
    
}
