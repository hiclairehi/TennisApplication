/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Club;
import model.ClubDAOException;
import model.Court;


/**
 *
 * @author jsoler
 */
public class LoginController implements Initializable {
    @FXML
    private TextField nickname;
    
    private BooleanProperty validNickname;
    
    @FXML
    private PasswordField password;
    
    private Club club;
    @FXML
    private Button add;
    @FXML
    private Label errorMessage;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            club= Club.getInstance();
            
        } catch (ClubDAOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            add.disableProperty().bind(Bindings.and(nickname.textProperty().isEmpty(), password.textProperty().isEmpty()));
            club.addSimpleData();
    }
        

    @FXML
    private void signUp(ActionEvent event) throws Exception  {
        Stage stage = (Stage) add.getScene().getWindow();
        stage.close();
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/views/SignUpFXML.fxml"));
        primaryStage.setTitle("Sign Up");
        primaryStage.setScene(new Scene(root,700,500));  
        primaryStage.initModality(Modality.APPLICATION_MODAL);
        primaryStage.show();
               
    }

    @FXML
    private void login(ActionEvent event) throws IOException {
        // check if the user is Member of the club
        if(!club.existsLogin(nickname.textProperty().getValueSafe())){
            errorMessage.setVisible(true);
            nickname.clear();
            password.clear();
        } else{
            // change window to the home page
            Stage stage = (Stage) add.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/HomeScreen.fxml"));
            Parent root = loader.load();
            
            HomeScreenController home = loader.getController();
            home.iniMember(nickname.getText());
            stage.setScene(new Scene(root));
            stage.setTitle("Home");
            stage.show();
        }
    }

    @FXML
    private void availability(ActionEvent event) {
        
    }
    
    
    
}
