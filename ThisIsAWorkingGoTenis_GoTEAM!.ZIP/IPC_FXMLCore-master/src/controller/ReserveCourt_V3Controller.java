package controller;

import javafx.scene.paint.Color;
import java.io.IOException;
import javafx.scene.control.Button;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Club;
import model.ClubDAOException;
import model.Court;
import model.Member;



public class ReserveCourt_V3Controller implements Initializable {

    @FXML
    private Button MenuButton;
    @FXML
    private Button LoginButton;
    @FXML
    private Button SignUpButton;
    @FXML
    private GridPane gridPane;
    @FXML
    private DatePicker datePicker;
    @FXML
    private Label CourtBookingStatus;
    @FXML
    private Button BookButton;
    
    private String member; 
    private Club club;

    private List<Button> selectedButtons = new ArrayList<>();
    @FXML
    private Label status;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        for (Node node : gridPane.getChildren()) {
            if (node instanceof Button) {
                Button button = (Button) node;
                button.setOnMouseClicked(this::handleButtonClick);
            }
        }
        
        
        try {
            club= Club.getInstance();
        } catch (ClubDAOException ex) {
            Logger.getLogger(ReserveCourt_V3Controller.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ReserveCourt_V3Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void iniMember(String m){
        member = m;
        status.setText("Hello "+ member);
    }
    
@FXML
private void handleButtonClick(MouseEvent event) {
    Button button = (Button) event.getSource();

    int timeIndex = GridPane.getRowIndex(button) - 1; // Adjust for header row
    int courtIndex = GridPane.getColumnIndex(button) - 1; // Adjust for header column

    if (selectedButtons.contains(button)) {
        // Button clicked again, deselect it
        selectedButtons.remove(button);
        button.setStyle("-fx-background-color: ;");
    } else {
        // Button clicked for the first time, select it
        selectedButtons.add(button);
        button.setStyle("-fx-background-color: green;");

        // Print time and court values in the CourtBookingStatus label
        String time = getTimeFromIndex(timeIndex);
        String court = getCourtFromIndex(courtIndex);
        CourtBookingStatus.setText("Booking: " + time + " at Court " + court);
    }

    // Enable or disable the BookButton based on the selected node count
    BookButton.setDisable(selectedButtons.isEmpty());
    
    // Clear the CourtBookingStatus label if no buttons are selected
    if (selectedButtons.isEmpty()) {
        CourtBookingStatus.setText("");
    }
}

@FXML
private void BookCourt(ActionEvent event) {
    // Set the background color of selected buttons to red and disable them
    for (Button button : selectedButtons) {
        button.setStyle("-fx-background-color: red;");
        button.setDisable(true);
    }

    // Clear the selected buttons list
    selectedButtons.clear();
    // Disable the BookButton
    BookButton.setDisable(true);

    // Clear the CourtBookingStatus label
    CourtBookingStatus.setText("");
}


    @FXML
    void myDatePicker(ActionEvent event) {
        
         LocalDate calendarValue  = datePicker.getValue();
         System.out.println(calendarValue);
         
            Court court = new Court();  // store in the court Name
//            Member member = new Member();
            
        LocalDateTime bookingDate = LocalDateTime.now(); 
        LocalTime fromHour = LocalTime.now(); // this has to be the hour clicked on the button...
        boolean paid = false; // Set the paid status
        
//    selectedButtons.clear();

//         club.registerBooking(bookingDate, calendarValue, fromHour, paid, court, member);

            //        Booking booking = new Booking(bookingDate, calendarValue, fromHour, paid, court,  member);

//         selectedButtons.clear();

         // listener to calendar, 
         // make button on actio nfor each button? if time is free greenm if not disabled. 
         // store in court Name, court time, 
         
         // problem : on action for all these buttons? hwo to make the screen change dependign on the day
            

        // first to test it out i would have to have the member data? 
        // public ArrayList<Booking> getForDayBookings(LocalDateforDay)
        // you can choose the court number, and the time 
         
    }




private String getTimeFromIndex(int index) {
    // Adjust index to match time range (9:00 to 20:00)
    int hour = index + 9;
    String time = String.format("%02d:00", hour);
    return time;
}

private String getCourtFromIndex(int index) {
    // Adjust index to match court number (1 to 6)
    int courtNumber = index + 1;
    return String.valueOf(courtNumber);
}
       

    
    // Helper methods for getting time and court information
    private String getTimeFromButton(Button button) {
        // Implement your logic to extract time information from the button
        // Example: return button.getText();
        return "";
    }
    
    private String getCourtFromButton(Button button) {
        // Implement your logic to extract court information from the button
        // Example: return button.getId();
        return "";
    }
    
    
    
    
    
    @FXML
    private void GoToMenu() throws IOException{
        Stage primaryStage =(Stage) MenuButton.getScene().getWindow();
        FXMLLoader load = new FXMLLoader(getClass().getResource("/views/HomeScreen.fxml"));
        Parent root = load.load();
        
        HomeScreenController home = load.getController();
        home.iniMember(member);
        
        primaryStage.setTitle("Home Menu");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    
    @FXML
    private void GoToLoginPage() throws IOException{
        closeCurrentStage();
        openNewStage("/views/LoginFXML.fxml", "Login");
    }
    
    @FXML
    private void GoToSignUpPage() throws IOException{
        closeCurrentStage();
        openNewStage("/views/SignUpFXML.fxml", "Sign Up");
    }
    
    private void closeCurrentStage(){
        Stage stage = (Stage) MenuButton.getScene().getWindow();
        stage.close();
    }
    
    private void openNewStage(String resource, String title) throws IOException{
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource(resource));
        primaryStage.setTitle(title);
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    
    
    
}




