
package controller;

import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Booking;
import model.Club;
import model.ClubDAOException;
import model.Member;


public class MyReservationController implements Initializable {

    @FXML
    private Button MenuButton;
    private Button LoginButton;
    private Button SignUpButton;
    
    private Club club;
    
    private Member member;
    
    private ObservableList<Booking> list =null;
    @FXML
    private Label test;
    @FXML
    private ListView<Booking> listview;
    @FXML
    private Button cancelButton;
    @FXML
    private Button payButton;
    
    private BooleanProperty selected;
    private BooleanProperty paid;
    private LocalDateTime currentDate ;
    

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeModel();
       
        selected = new SimpleBooleanProperty(listview.getSelectionModel().getSelectedIndex() ==-1);
        paid = new SimpleBooleanProperty(listview.getSelectionModel().getSelectedItem().getPaid());
        BooleanBinding b = Bindings.or(selected, paid);
        payButton.disableProperty().bind(Bindings.not(b));
        
        cancelButton.disableProperty().bind(Bindings.equal(listview.getSelectionModel().selectedItemProperty(), -1));
     
        
        
    }
    
    public void initializeModel(){
    try {
            club= Club.getInstance();
        } catch (ClubDAOException ex) {
            Logger.getLogger(MyReservationController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MyReservationController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
        
        
        
    }
    

    
    @FXML
    private void GoToMenu() throws IOException{
        
        Stage primaryStage = (Stage) MenuButton.getScene().getWindow();
        FXMLLoader loader =new FXMLLoader(getClass().getResource("/views/HomeScreen.fxml"));
        Parent root = loader.load();
        
        HomeScreenController home = loader.getController();
        home.iniMember(member);
        
        primaryStage.setTitle("GreenBall-Home");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    
    
    public void iniMember(Member m){
        this.member=m;
        if(m==null){ LoginButton.setVisible(true);  SignUpButton.setVisible(true);}
        
        
        List<Booking> resrv = club.getUserBookings(member.getNickName());
        list = FXCollections.observableList(resrv);
        listview.setItems(list);
        
        listview.setCellFactory(c -> new BookingCell());
        
    }

    @FXML
    private void deleteReservation(ActionEvent event) {
        
        Booking booking = listview.getSelectionModel().getSelectedItem();
        currentDate = LocalDateTime.now();
        LocalDateTime bookingDate =listview.getSelectionModel().getSelectedItem().getBookingDate();
        
        Duration duration = Duration.between(currentDate, bookingDate);
        Duration tf = Duration.ofHours(24);
        
        if(duration.compareTo(tf)>0){
            
            try {
                club.removeBooking(booking);
            } catch (ClubDAOException ex) {
                Logger.getLogger(MyReservationController.class.getName()).log(Level.SEVERE, null, ex);
            }
            int index = listview.getSelectionModel().getSelectedIndex();
            if(index != -1){ listview.getItems().remove(index);}
        }
    }
    
    
    class BookingCell extends ListCell<Booking>{
        
        @Override
        protected void updateItem(Booking b, boolean bln){
            super.updateItem(b, bln);
            if(bln || b==null){
                setText("No reservation for the moment.");
            }else{
                String s ="";
                if(b.getPaid()){ s= "Paid";
                }else{s= "Not Paid";}
                setText(b.getMadeForDay().toString() +"  "+b.getCourt().toString()+"  "+b.getFromTime().toString()+"  "+s);
            }
        }
    }
    
    
}
