import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class SuccesMessageController {

    @FXML
    private Button court1Button;

    @FXML
    private Button court2Button;

    @FXML
    private Button court3Button;

    @FXML
    private Button court4Button;

    @FXML
    private Button court5Button;

    @FXML
    private Button court6Button;
    
    

}
