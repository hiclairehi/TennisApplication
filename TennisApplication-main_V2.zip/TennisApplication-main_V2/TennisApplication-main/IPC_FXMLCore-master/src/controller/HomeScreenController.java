package controller;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HomeScreenController {

    @FXML
    private Button BookTennisCourt;

    @FXML
    private Label homeLabel;

    @FXML
    private Button myReservationButton;

    @FXML
    private Label updateProfileLabel;

    @FXML
    void BookTennisCourtAction(ActionEvent event) throws IOException {
        Stage stage = (Stage) BookTennisCourt.getScene().getWindow();
        stage.close();
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/views/ReserveCourt_V3.fxml"));
        primaryStage.setTitle("Home Menu");
        primaryStage.setScene(new Scene(root));  
        primaryStage.show();

    }

    @FXML
    void ReservationAction(ActionEvent event) throws IOException {
        Stage stage = (Stage) myReservationButton.getScene().getWindow();
        stage.close();
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("/views/MyReservations.fxml"));
        primaryStage.setTitle("Home Menu");
        primaryStage.setScene(new Scene(root));  
        primaryStage.show();

    }

}
