package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Binding;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Club;
import model.ClubDAOException;
import model.Member;

public class SignUpController implements Initializable {


    @FXML
    private TextField creditCardField;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField nickNameField;


    @FXML
    private TextField phoneNumberField;
    
    private Club club;
    @FXML
    private Label taken;
    @FXML
    private ImageView myImageView;
    @FXML
    private Label pass;
    
    @FXML
    private Button submit;
    
    @FXML
    private PasswordField password;
    
    private BooleanProperty validNickname;
    private BooleanProperty validPassword;
    private BooleanProperty validData;
    @FXML
    private TextField svc;
    
    private Member m;
    
   

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            club= Club.getInstance();
        } catch (ClubDAOException ex) {
            Logger.getLogger(SignUpController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SignUpController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        validNickname= new SimpleBooleanProperty(Boolean.FALSE);
        validPassword = new SimpleBooleanProperty(Boolean.FALSE);
        validData = new SimpleBooleanProperty(Boolean.FALSE);
        
        BooleanBinding validFields =Bindings.and(validNickname, validPassword).and(validData);
        submit.disableProperty().bind(Bindings.not(validFields));
       
       // submit.setDisable(true);
        //BooleanBinding validField = Bindings.and(nickNameField.textProperty().isEmpty(), password.textProperty().isEmpty());
        //BooleanBinding validFields = Bindings.and(firstNameField.textProperty().isEmpty(), lastNameField.textProperty().isEmpty());
        //submit.disableProperty().bind(Bindings.and(validField,validFields));
        
        nickNameField.focusedProperty().addListener((observable,oldValue, newValue)->{
            if(!newValue){
                checkNickname();
            }
        });
        
        password.focusedProperty().addListener((observable, oldValue, newValue)->{
            if(!newValue){ checkPassword();}
        });
        
        firstNameField.focusedProperty().addListener((observable,ooldValue,newValue)->{
            if(!newValue){ 
                if(!firstNameField.textProperty().getValueSafe().isEmpty()){ validData.setValue(Boolean.TRUE);}
            }
        });
        
        lastNameField.focusedProperty().addListener((observable,oldValue, newValue)->{
            if(!newValue){
                if(!lastNameField.textProperty().getValueSafe().isEmpty()){ validData.setValue(Boolean.TRUE);}
            }
        });
        
        
        
    }
    
    
    @FXML
    void SubmitButton(ActionEvent event) throws IOException, ClubDAOException  {
        m=club.registerMember(firstNameField.getText(), lastNameField.getText(), phoneNumberField.getText(), nickNameField.getText(), password.getText(), creditCardField.getText(), Integer.parseInt(svc.getText()), null);
        
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Sign up confirmation");
        alert.setHeaderText("Your sign up was successful");
        alert.setContentText("Login to continue");
        
    }
    
    public void checkNickname(){
        if(club.existsLogin(nickNameField.textProperty().getValueSafe()) || nickNameField.textProperty().getValueSafe().contains(" ")){
                    taken.setText("Invalid nickname, try again.");
                    taken.setVisible(true);
                    validNickname.setValue(Boolean.FALSE);
                    nickNameField.requestFocus();
                    
        }else{
            validNickname.setValue(Boolean.TRUE);
            taken.setVisible(false);
        }
    
    }
    
    public void checkPassword(){
        if(password.textProperty().getValueSafe().length()<6){
            validPassword.setValue(Boolean.FALSE);
            pass.setVisible(true);
            pass.setText("Password must be at least 6 characters.");
            password.requestFocus();
        }else{
            validPassword.setValue(Boolean.TRUE);
            pass.setVisible(false);
        }
    }
    
    public void checkData(){
        if(!firstNameField.textProperty().getValueSafe().isEmpty() && !lastNameField.textProperty().getValueSafe().isEmpty()){
            validData.setValue(Boolean.TRUE);
        }else{ 
            validData.setValue(Boolean.FALSE);
        
        }
    }

    @FXML
    private void addPicture(MouseEvent event) {
    }
    
}