
package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


public class MyReservationController implements Initializable {

    @FXML
    private Button MenuButton;
    @FXML
    private Button LoginButton;
    @FXML
    private Button SignUpButton;
    @FXML
    private TableView<Reservation> reservationTable;
    @FXML
    private TableColumn<?, ?> dateColumn;
    @FXML
    private TableColumn<Reservation, String> timeColumn;
    @FXML
    private TableColumn<Reservation, String> courtColumn;
    @FXML
    private TableColumn<?, ?> nicknameColumn;
    
    private List<Reservation> reservations;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        reservations = new ArrayList<>();
        setupTableColumns();
    }    
    
    public void addReservation(String time, String court) {
        Reservation reservation = new Reservation(time, court);
        reservations.add(reservation);
        reservationTable.getItems().add(reservation);
    }
    
    public void removeReservation(String time, String court) {
        Reservation reservationToRemove = null;
        for (Reservation reservation : reservations) {
            if (reservation.getTime().equals(time) && reservation.getCourt().equals(court)) {
                reservationToRemove = reservation;
                break;
            }
        }
        
        if (reservationToRemove != null) {
            reservations.remove(reservationToRemove);
            reservationTable.getItems().remove(reservationToRemove);
        }
    }
    
    public void setupTableColumns() {
        timeColumn.setCellValueFactory(new PropertyValueFactory<>("time"));
        courtColumn.setCellValueFactory(new PropertyValueFactory<>("court"));
    }
    
    public static class Reservation {
        private String time;
        private String court;
        
        public Reservation(String time, String court) {
            this.time = time;
            this.court = court;
        }
        
        public String getTime() {
            return time;
        }
        
        public String getCourt() {
            return court;
        }
    }
    
    @FXML
    private void GoToMenu() throws IOException{
        closeCurrentStage();
        openNewStage("/views/HomeScreen.fxml", "Home Menu");
    }
    
    @FXML
    private void GoToLoginPage() throws IOException{
        closeCurrentStage();
        openNewStage("/views/LoginFXML.fxml", "Login");
    }
    
    @FXML
    private void GoToSignUpPage() throws IOException{
        closeCurrentStage();
        openNewStage("/views/SignUpFXML.fxml", "Sign Up");
    }
    
    @FXML
    private void closeCurrentStage(){
        Stage stage = (Stage) MenuButton.getScene().getWindow();
        stage.close();
    }
    
    @FXML
    private void openNewStage(String resource, String title) throws IOException{
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource(resource));
        primaryStage.setTitle(title);
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    
}
