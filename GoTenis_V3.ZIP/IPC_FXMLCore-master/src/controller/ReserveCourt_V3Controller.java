package controller;

import javafx.scene.paint.Color;
import java.io.IOException;
import javafx.scene.control.Button;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import java.util.List;



public class ReserveCourt_V3Controller {

    @FXML
    private Button MenuButton;
    @FXML
    private Button LoginButton;
    @FXML
    private Button SignUpButton;
    @FXML
    private DatePicker Calender;
    @FXML
    private GridPane gridPane;
    @FXML
    private Label CourtBookingStatus;
    @FXML
    private Button BookButton;
    
    private List<Button> selectedButtons = new ArrayList<>();
    
    //private MyReservationController myReservationController;
    
    
    private void initialize() {
        for (Node node : gridPane.getChildren()) {
            if (node instanceof Button) {
                Button button = (Button) node;
                button.setOnMouseClicked(this::handleButtonClick);
            }
        }
    }   
    
    
@FXML
private void handleButtonClick(MouseEvent event) {
    Button button = (Button) event.getSource();

    int timeIndex = GridPane.getRowIndex(button) - 1; // Adjust for header row
    int courtIndex = GridPane.getColumnIndex(button) - 1; // Adjust for header column

    if (selectedButtons.contains(button)) {
        // Button clicked again, deselect it
        selectedButtons.remove(button);
        button.setStyle("-fx-background-color: ;");
    } else {
        // Button clicked for the first time, select it
        selectedButtons.add(button);
        button.setStyle("-fx-background-color: green;");

        // Print time and court values in the CourtBookingStatus label
        String time = getTimeFromIndex(timeIndex);
        String court = getCourtFromIndex(courtIndex);
        CourtBookingStatus.setText("Booking: " + time + " at Court " + court);
    }

    // Enable or disable the BookButton based on the selected node count
    BookButton.setDisable(selectedButtons.isEmpty());
    
    // Clear the CourtBookingStatus label if no buttons are selected
    if (selectedButtons.isEmpty()) {
        CourtBookingStatus.setText("");
    }
}

@FXML
private void BookCourt(ActionEvent event) {
    // Set the background color of selected buttons to red and disable them
    for (Button button : selectedButtons) {
        button.setStyle("-fx-background-color: red;");
        button.setDisable(true);
    }

    // Clear the selected buttons list
    selectedButtons.clear();
    // Disable the BookButton
    BookButton.setDisable(true);

    // Clear the CourtBookingStatus label
    CourtBookingStatus.setText("");
}

private String getTimeFromIndex(int index) {
    // Adjust index to match time range (9:00 to 20:00)
    int hour = index + 9;
    String time = String.format("%02d:00", hour);
    return time;
}

private String getCourtFromIndex(int index) {
    // Adjust index to match court number (1 to 6)
    int courtNumber = index + 1;
    return String.valueOf(courtNumber);
}
       

    
    // Helper methods for getting time and court information
    private String getTimeFromButton(Button button) {
        // Implement your logic to extract time information from the button
        // Example: return button.getText();
        return "";
    }
    
    private String getCourtFromButton(Button button) {
        // Implement your logic to extract court information from the button
        // Example: return button.getId();
        return "";
    }
    
    
    
    
    
    @FXML
    private void GoToMenu() throws IOException{
        closeCurrentStage();
        openNewStage("/views/HomeScreen.fxml", "Home Menu");
    }
    
    @FXML
    private void GoToLoginPage() throws IOException{
        closeCurrentStage();
        openNewStage("/views/LoginFXML.fxml", "Login");
    }
    
    @FXML
    private void GoToSignUpPage() throws IOException{
        closeCurrentStage();
        openNewStage("/views/SignUpFXML.fxml", "Sign Up");
    }
    
    @FXML
    private void closeCurrentStage(){
        Stage stage = (Stage) MenuButton.getScene().getWindow();
        stage.close();
    }
    
    @FXML
    private void openNewStage(String resource, String title) throws IOException{
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource(resource));
        primaryStage.setTitle(title);
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

}


