/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Club;
import model.ClubDAOException;
import model.Court;
import model.Member;


/**
 *
 * @author jsoler
 */
public class LoginController implements Initializable {
    @FXML
    private TextField nickname;
    
    @FXML
    private PasswordField password;
    
    private Club club;
    @FXML
    private Button add;
    @FXML
    private Label errorMessage;
    
    private String member;
    @FXML
    private Label test;
    
    private BooleanProperty validNickname;
    
    private BooleanProperty validPassword;
    
    private Member m;
    
    
    
    
    
    
    
    //=========================================================
    // event handler, fired when button is clicked or 
    //                      when the button has the focus and enter is pressed
    //*private void handleButtonAction(ActionEvent event) {
    // labelMessage.setText("Hello, this is your first JavaFX project - IPC");}
    
    //=========================================================
    // you must initialize here all related with the object 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            club= Club.getInstance();
            
        } catch (ClubDAOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
            add.setDisable(true);
            club.addSimpleData();
            
           validNickname = new SimpleBooleanProperty(Boolean.FALSE);
           validPassword = new SimpleBooleanProperty(Boolean.FALSE);
           
           nickname.focusedProperty().addListener((observable, oldValue, newValue)->{
               if(!newValue){
                   if(!nickname.getText().isEmpty()){   validNickname.setValue(true);}
               }
           });
           
           password.textProperty().addListener((observable, oldValue, newValue)->{
               if(!newValue.isEmpty()){
                    validPassword.setValue(true);
               } else{  validPassword.setValue(false);}
           });
           
           BooleanBinding b = Bindings.and(validNickname, validPassword);
           add.disableProperty().bind(Bindings.not(b));
           
            
            
            
        
    }
        

    @FXML
    private void signUp(ActionEvent event) throws Exception  {
        
        Stage stage = (Stage) add.getScene().getWindow();
        stage.close();
        Stage primaryStage = new Stage();
        
        Parent root = FXMLLoader.load(getClass().getResource("/views/SignUpFXML.fxml"));
        primaryStage.setTitle("GreenBall-Sign Up");
        
        primaryStage.setScene(new Scene(root,700,500));  
        primaryStage.initModality(Modality.APPLICATION_MODAL);
        primaryStage.showAndWait();
               
    }

    @FXML
    private void login(ActionEvent event) throws IOException {
        // check if the user is Member of the club
         m = club.getMemberByCredentials(nickname.textProperty().getValueSafe(), password.textProperty().getValueSafe());
         
        if(!club.existsLogin(nickname.getText()) || m==null){
            errorMessage.setVisible(true);
            nickname.clear();
            password.clear();
        }else{
        
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/HomeScreen.fxml"));
            Parent root = loader.load();  
            
            HomeScreenController home = loader.getController();
            String n=nickname.getText();
            home.iniMember(m);
              
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.setTitle("GreenBall-Home");
            stage.show();
            Stage s = (Stage) nickname.getScene().getWindow();
            s.close();
        }
            // change window to the home page
            
            
            
        
    }

    @FXML
    private void availability(ActionEvent event) throws IOException {
        
        Stage stage = (Stage) add.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/ReserveCourt_V3.fxml"));
        Parent root = loader.load();
        
        stage.setScene(new Scene(root));
        stage.setTitle("GreenBall-Bookings");
        
        stage.show();
        
       
    }
    
    
    
}
