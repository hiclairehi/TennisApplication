package controller;

import javafx.scene.paint.Color;
import java.io.IOException;
import javafx.scene.control.Button;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Booking;
import model.Club;
import model.ClubDAOException;
import model.ClubDAO;



import model.Court;
import model.Member;



public class ReserveCourt_V3Controller implements Initializable {

    @FXML
    private Button MenuButton;
    @FXML
    private Button LoginButton;
    @FXML
    private Button SignUpButton;
    @FXML
    private GridPane gridPane;
    @FXML
    private DatePicker datePicker;
    @FXML
    private Label CourtBookingStatus;
    @FXML
    private Button BookButton;
    
    private Member member; 
    private Court crt;
    private Club club;
    private List<Booking> booking ;
    private List<Button> selectedButtons = new ArrayList<>();
    private Label status;
    
    LocalDate calendarValue;
    
    String time; 
    
    String court; 
    
    Court registerCourt;
    
    private int slots=0;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        for (Node node : gridPane.getChildren()) {
            if (node instanceof Button) {
                Button button = (Button) node;
                button.setOnMouseClicked(this::handleButtonClick);
            }
        }
        
        try {
            club= Club.getInstance();
        } catch (ClubDAOException ex) {
            Logger.getLogger(ReserveCourt_V3Controller.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ReserveCourt_V3Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        datePicker.setValue(LocalDate.now());
        displayBooking(datePicker.getValue());
    }
    
    
    public void iniMember(Member m){
        this.member= m;
        if(member ==null){ LoginButton.setVisible(true);  SignUpButton.setVisible(true);}
    }


  @FXML
private void handleButtonClick(MouseEvent event) {


    Button button = (Button) event.getSource();

    int timeIndex = GridPane.getRowIndex(button) - 1; // Adjust for header row
    int courtIndex = GridPane.getColumnIndex(button) - 1; // Adjust for header column

    
    time = getTimeFromIndex(timeIndex);
    court = getCourtFromIndex(courtIndex);
    for (Button selectedButton : selectedButtons) {
        selectedButton.setStyle("-fx-background-color: ;");
    }
    selectedButtons.clear();
    selectedButtons.add(button);
    button.setStyle("-fx-background-color: green;");
  
        try {
            registerCourt=Club.getInstance().getCourt("Pista "+court);
        } catch (ClubDAOException ex) {
            Logger.getLogger(ReserveCourt_V3Controller.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ReserveCourt_V3Controller.class.getName()).log(Level.SEVERE, null, ex);
        }

    CourtBookingStatus.setText("Booking: " + time + " at Court " + court);

    // Enable the BookButton
    BookButton.setDisable(false);
}  
    
    
    
@FXML
private void BookCourt(ActionEvent event) {
    if(slots < club.getBookingSlots() ){
    for (Button button : selectedButtons) {
        button.setStyle("-fx-background-color: red;");
        button.setDisable(true);
    }

    selectedButtons.clear();
    BookButton.setDisable(true);

    CourtBookingStatus.setText("");
    LocalDateTime bookingDate = LocalDateTime.now(); // Reservation date

    Member registerMember = member;
    System.out.println(registerMember);
    System.out.println(bookingDate);
    System.out.println(calendarValue);
    System.out.println(LocalTime.parse(time));

    try {
        if (registerMember != null) {
            club.registerBooking(bookingDate, calendarValue, LocalTime.parse(time), true, registerCourt, registerMember);
            slots++;
        } else {
        }
    } catch (ClubDAOException e) {
        System.out.print("Error " +e.getMessage());
    }
    }
}


@FXML
void myDatePicker(ActionEvent event) {
    calendarValue = datePicker.getValue();
    CourtBookingStatus.setText("");
    
    if(!datePicker.getValue().equals(LocalDate.now())){ slots =0;}

    displayBooking(calendarValue);
}



private String getTimeFromIndex(int index) {
    int hour = index + 9;
    String time = String.format("%02d:00", hour);
    return time;
}

private String getCourtFromIndex(int index) {
    int courtNumber = index + 1;
    return String.valueOf(courtNumber);
}

    
    @FXML
    private void GoToMenu() throws IOException{
        Stage primaryStage =(Stage) MenuButton.getScene().getWindow();
        FXMLLoader load = new FXMLLoader(getClass().getResource("/views/HomeScreen.fxml"));
        Parent root = load.load();
        
        HomeScreenController home = load.getController();
        home.iniMember(member);
        
        primaryStage.setTitle("Home Menu");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    
    @FXML
    private void GoToLoginPage() throws IOException{
        closeCurrentStage();
        openNewStage("/views/LoginFXML.fxml", "Login");
    }
    
    @FXML
    private void GoToSignUpPage() throws IOException{
        closeCurrentStage();
        openNewStage("/views/SignUpFXML.fxml", "Sign Up");
    }
    
    private void closeCurrentStage(){
        Stage stage = (Stage) MenuButton.getScene().getWindow();
        stage.close();
    }
    
    private void openNewStage(String resource, String title) throws IOException{
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource(resource));
        primaryStage.setTitle(title);
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    
    public void displayBooking(LocalDate date){
        
        for (Node node : gridPane.getChildren()) {
        if (node instanceof Button) {
            Button button = (Button) node;
            button.setStyle("-fx-background-color: ;");
            button.setDisable(false);

        
        }}
    List<Booking> bookings = club.getForDayBookings(date);

    for (Node node : gridPane.getChildren()) {
        if (node instanceof Button) {
            Button button = (Button) node;
            int timeIndex = GridPane.getRowIndex(button) - 1;
            int courtIndex = GridPane.getColumnIndex(button) - 1;
            String time = getTimeFromIndex(timeIndex);
            String court = getCourtFromIndex(courtIndex);
            Court currentCourt = new Court("Pista " + court);
            

            boolean isCourtBooked = false;
            for (Booking booking : bookings) {

                if (booking.getFromTime().toString().equals(time) && booking.getCourt().getName().equals(currentCourt.getName() )) {
                    isCourtBooked = true;
                    System.out.println("insideIfStatemnt");
                    
                    button.setStyle("-fx-background-color: #FF6347;"); // Red color for booked court
                    button.setDisable(true); // Disable the button if court is booked
                    button.setText(booking.getMember().getNickName()); // display nickname
                    
                } 


            } 


        }
    }
    
        
    
    }
    
   
    
}






