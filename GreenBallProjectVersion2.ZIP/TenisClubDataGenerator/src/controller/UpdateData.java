/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Member;

/**
 *
 * @author yusar
 */
public class UpdateData implements Initializable{

    @FXML
    private Button saveButton;
    @FXML
    private TextField phone;
    @FXML
    private TextField firstname;
    @FXML
    private TextField lastname;
    @FXML
    private TextField svc;
    @FXML
    private ImageView myImage;

    private Member member;
    @FXML
    private PasswordField password;
    @FXML
    private TextField credit;
    
    private Image image;
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
        BooleanBinding b = Bindings.and(firstname.textProperty().isEmpty(), lastname.textProperty().isEmpty()).and(password.textProperty().isEmpty());
        BooleanBinding bl = Bindings.and(b, phone.textProperty().isEmpty());
        saveButton.disableProperty().bind(bl);
         
    }

    @FXML
    private void goMenu(ActionEvent event) throws IOException {
        
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/HomeScreen.fxml"));
        Parent root = loader.load();
        
        HomeScreenController home = loader.getController();
        home.iniMember(member);
        
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.setTitle("GreenBall-Home");
        stage.setScene(new Scene(root));
        stage.show();
        
        
    }

    @FXML
    private void saveData(ActionEvent event) {
        if(!firstname.getText().isEmpty() && !lastname.getText().isEmpty() && !password.getText().isEmpty() && !phone.getText().isEmpty()){
            
            member.setName(firstname.getText());
            member.setSurname(lastname.getText());
            member.setPassword(password.getText());
            member.setTelephone(phone.getText());
            
            if(!credit.getText().isEmpty() && !svc.getText().isEmpty()){
                member.setCreditCard(credit.getText());
                member.setSvc(Integer.parseInt(svc.getText()));
            }
            if(myImage!=null){ member.setImage(image);}
            
        }
        
        //add listener and boolean property 
        
    }

    @FXML
    private void changePhoto(MouseEvent event) throws FileNotFoundException {
        
        FileChooser imageChooser = new FileChooser();
        
        imageChooser.setTitle("Choose a profile picture");
        imageChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images","*.png","*.jpg"));
        
        File selectedImage = imageChooser.showOpenDialog(((Node) event.getSource()).getScene().getWindow());
        
        if(selectedImage != null){
            String url =selectedImage.getAbsolutePath();
            image = new Image(new FileInputStream(url));
            myImage.imageProperty().set(image);
        }
    }
    
    public void iniMember(Member m){
        member =m;
        firstname.setText(m.getName());
        lastname.setText(m.getSurname());
        phone.setText(m.getTelephone());
        password.setText(m.getPassword());
        
        if(m.checkHasCreditInfo()){
            
            credit.setText(m.getCreditCard());
            svc.setText(String.valueOf(m.getSvc()));
            myImage.imageProperty().setValue(m.getImage());
            
        }
        
        
    }
    
    
}
