
package controller;

import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Booking;
import model.Club;
import model.ClubDAOException;
import model.Member;


public class MyReservationController implements Initializable {

    @FXML
    private Button MenuButton;
  
    @FXML
    private Button cancelButton;
   
    @FXML
    private TableView<Booking> tableView;
    @FXML
    private TableColumn<Booking, String> dateColumn;
    @FXML
    private TableColumn<Booking, String> courtColumn;
    @FXML
    private TableColumn<Booking, String> timeColumn;
    @FXML
    private TableColumn<Booking, String> statusColumn;
    
    private ObservableList<Booking> list ;
    
    private Club club;
    
    private Member member;
    
    private LocalDate currentDate ;
    
    private LocalTime currTime;
  
    

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeModel();
        
        dateColumn.setCellValueFactory(bookingRow ->{ return new SimpleStringProperty(bookingRow.getValue().getMadeForDay().toString());});
        
        courtColumn.setCellValueFactory(bookingRow ->{return new SimpleStringProperty(bookingRow.getValue().getCourt().getName());});
        
        timeColumn.setCellValueFactory(bookingRow -> {return new SimpleStringProperty(bookingRow.getValue().getFromTime().toString()+"-"+bookingRow.getValue().getFromTime().plusMinutes(90).toString() );});
        
        statusColumn.setCellValueFactory(bookingRow->{ 
            String s="";
                if(bookingRow.getValue().getPaid()){ s= "Paid";
                }else{s="Not paid";}
                return new SimpleStringProperty(s);
                    });
        
       cancelButton.disableProperty().bind(Bindings.equal(tableView.getSelectionModel().selectedIndexProperty(),-1));
        
       
        
        
    }
    
    public void initializeModel(){
    try {
            club= Club.getInstance();
        } catch (ClubDAOException ex) {
            Logger.getLogger(MyReservationController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MyReservationController.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    

    
    @FXML
    private void GoToMenu() throws IOException{
        
        openNewStage("/views/HomeScreen.fxml", "Home Menu");
    }
    
    
    private void openNewStage(String resource, String title) throws IOException{
        Stage primaryStage = (Stage) MenuButton.getScene().getWindow();
        FXMLLoader loader =new FXMLLoader(getClass().getResource(resource));
        Parent root = loader.load();
        
        HomeScreenController home = loader.getController();
        home.iniMember(member);
        
        primaryStage.setTitle(title);
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }
    
    public void iniMember(Member m){
        this.member=m;
        
        List<Booking> reservation  =  club.getUserBookings(member.getNickName());
        
        list =FXCollections.observableArrayList(reservation);
        
        tableView.setItems(list);
        
        
    }

    @FXML
    private void deleteReservation(ActionEvent event) {
        
        Booking booking = tableView.getSelectionModel().getSelectedItem();
        //int index = tableView.getSelectionModel().getSelectedIndex();
        
        currentDate = LocalDate.now();
        currTime = LocalTime.now();
        LocalDateTime endDate = LocalDateTime.of(currentDate, currTime);
        
        LocalDate bookingDate = booking.getMadeForDay();
        LocalTime bookingTime = booking.getFromTime();
        LocalDateTime startDate = LocalDateTime.of(bookingDate, bookingTime);
        
        Duration duration = Duration.between(endDate, startDate);
        long durr = duration.toHours();

        
        if(durr> 24){
                 
             int index = tableView.getSelectionModel().selectedIndexProperty().getValue();
             if(index >= 0){ list.remove(index);}
            try {
                boolean remove = club.removeBooking(booking);
                
            } catch (ClubDAOException ex) {
                Logger.getLogger(MyReservationController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        }
        
            
        }
        
        
    }
    
    
    
    
    

